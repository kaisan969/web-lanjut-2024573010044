

<?php $__env->startSection('title', 'About - Partial views Demo'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class ="theme-demo <?php echo e($theme === 'dark' ? 'bg-dark border-light' : 'bg-white border'); ?> mb-4">
            <h1 class="mb-4">About-Partial Views</h1>
            <p class="lead">Halaman ini mendemonstrasikan pengunaan <strong>partial Views</strong> dengan <code><code>&#64;include</code></code> directive.</p>
        </div>

        <h3 class="mb-4">Tim kami</h3>
        <div class="row">
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalc7513f5efe693eda861651c8c1060032 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7513f5efe693eda861651c8c1060032 = $attributes; } ?>
<?php $component = App\View\Components\TeamMember::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('team-member'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TeamMember::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($member['name'] ),'role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($member['role'] ),'theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($theme),'avatar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute( ['👩‍💻','👩‍🌾','🤵‍♀️'][$loop->index]),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Bergabung sejak 2024 dan kontribusi dalam pengembangan')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7513f5efe693eda861651c8c1060032)): ?>
<?php $attributes = $__attributesOriginalc7513f5efe693eda861651c8c1060032; ?>
<?php unset($__attributesOriginalc7513f5efe693eda861651c8c1060032); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7513f5efe693eda861651c8c1060032)): ?>
<?php $component = $__componentOriginalc7513f5efe693eda861651c8c1060032; ?>
<?php unset($__componentOriginalc7513f5efe693eda861651c8c1060032); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php echo $__env->make('partials.team-stats', ['theme' => $theme], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/about.blade.php ENDPATH**/ ?>