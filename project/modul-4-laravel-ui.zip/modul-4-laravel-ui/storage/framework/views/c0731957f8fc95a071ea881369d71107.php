<?php if(!empty($message)): ?>
<div class="alert alert-<?php echo e($type ?? 'info'); ?> alert-dismissible fade show" role="alert">
    <?php echo e($message); ?>

    <button type="button" class="btn-close" data-bs-dissmiss="alert"></button>
</div>
<?php endif; ?><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/partials/alert.blade.php ENDPATH**/ ?>