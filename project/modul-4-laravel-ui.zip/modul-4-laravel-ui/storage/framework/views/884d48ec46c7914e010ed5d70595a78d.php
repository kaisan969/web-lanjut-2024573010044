<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['theme' => 'light', 'icon' => null, 'title', 'description', 'badge' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['theme' => 'light', 'icon' => null, 'title', 'description', 'badge' => null]); ?>
<?php foreach (array_filter((['theme' => 'light', 'icon' => null, 'title', 'description', 'badge' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="card feature-card h-100 <?php echo e(($theme ?? 'light') === 'dark' ? 'bg-secondary text-white' : ''); ?>">
    <div class="card-body">
        <div class="d-flex align-items-center mb-3">
            <span class="fs-2 me-3"><?php echo e($icon ?? '⭐'); ?></span>
            <h5 class="card-title mb-0"><?php echo e($title); ?></h5>
         </div> 
            <p class="card-text"><?php echo e($description); ?></p>
            <?php if(isset($badge)): ?>
                <span class="badge <?php echo e($theme ==='dark' ? 'bg-light text-dark' : 'bg-dark'); ?>"></span>
            <?php endif; ?>
        
    </div>
</div><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/components/feature-card.blade.php ENDPATH**/ ?>