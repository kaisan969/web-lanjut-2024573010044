<nav class="navbar navbar-expand-lg <?php echo e($theme ==='dark' ? 'navbar-dark bg-dark' : 'navbar-light bg-light'); ?> fixed-top shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>">
            laravel UI Demo
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">About</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>" href="<?php echo e(route('profile')); ?>">Profile</a>
                </li>
            </ul>   

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        Theme: <?php echo e(ucfirst($theme)); ?>

                    </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="<?php echo e(route('switch-theme', 'light')); ?>">Light Mode</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('switch-theme', 'dark')); ?>">Dark Mode</a></li>
                </ul>
             </li>
          </ul>
      </div>
  </div>
</nav><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/partials/navigation.blade.php ENDPATH**/ ?>