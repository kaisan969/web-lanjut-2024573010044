

<?php $__env->startSection('title', 'Profile - Theme Demo'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="theme-demo <?php echo e($theme === 'dark' ? 'bg-dark border-light' : 'bg-white border'); ?> mb-4">
            <h1 class="mb-4">Profile - Theme Demo</h1>
            <p class="lead">Halaman ini menunjukkan implementasi <strong>Theme Switching</strong> dengan session persistence.</p>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="card <?php echo e($theme === 'dark' ? 'bg-dark border-light' : ''); ?> text-center">
                    <div class="card-body">
                        <div class="mb-3">
                            <span class="fs-1">👤</span>
                        </div>
                        <h4><?php echo e($user['name']); ?></h4>
                        <p class="text-muted"><?php echo e($user['email']); ?></p>
                        <p class="text-muted">Bergabung: <?php echo e(date('d M Y', strtotime($user['join-date']))); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card <?php echo e($theme === 'dark' ? 'bg-dark border-light' : ''); ?>">
                    <div class="card-header">
                        <h5>Preferensi Pengguna</h5>
                    </div>
                    <div class="card-body">
                        <h6>Theme Saat Ini:</h6>
                        <div class="alert alert-<?php echo e($theme === 'dark' ? 'dark' : 'info'); ?> d-flex align-items-center">
                            <span class="me-2 fs-4"><?php echo e($theme === 'dark' ? '🌙' : '☀️'); ?></span>
                            <div>
                                <strong>Mode <?php echo e(ucfirst($theme)); ?></strong> - 
                                <?php if($theme === 'dark'): ?>
                                    Nyaman di malam hari dan mengurangi ketegangan mata.
                                <?php else: ?>
                                    Cerah dan jelas, cocok untuk siang hari.
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <h6 class="mt-4">Preferensi Lainnya:</h6>
                        <div class="d-flex flex-wrap gap-2">
                            <?php $__currentLoopData = $user['preferences']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-secondary"><?php echo e($pref); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <div class="mt-4">
                            <h6>Change Theme:</h6>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('switch-theme', 'light')); ?>" 
                                   class="btn btn-<?php echo e($theme === 'light' ? 'primary' : 'outline-primary'); ?>">
                                    Light Mode
                                </a>
                                <a href="<?php echo e(route('switch-theme', 'dark')); ?>" 
                                   class="btn btn-<?php echo e($theme === 'dark' ? 'primary' : 'outline-primary'); ?>">
                                    Dark Mode
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/profile.blade.php ENDPATH**/ ?>