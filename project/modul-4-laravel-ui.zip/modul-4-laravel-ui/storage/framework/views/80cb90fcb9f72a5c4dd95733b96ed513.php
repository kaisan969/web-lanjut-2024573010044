<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'role', 'description', 'avatar' => null, 'theme' => 'light']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'role', 'description', 'avatar' => null, 'theme' => 'light']); ?>
<?php foreach (array_filter((['name', 'role', 'description', 'avatar' => null, 'theme' => 'light']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class ="col-md-4 mb-4">
    <div class="card <?php echo e($theme === 'dark' ? 'bg-dark border-light': ''); ?> h-100">
        <div class="card-body text-center">
            <div class="mb-3">
                <span class="fs-1"><?php echo e($avatar ?? '👤'); ?></span>

            </div>
            <h5 class="card-title"><?php echo e($name); ?></h5>
            <p class="card-text text-muted"><?php echo e($role); ?></p>
            <p class="card-text"><?php echo e($description); ?></p>
     </div>
 </div> 
</div><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/components/team-member.blade.php ENDPATH**/ ?>