

<?php $__env->startSection('title', 'Home - Integrated Demo'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="theme-demo <?php echo e($theme === 'dark' ? 'bg-dark border-light' : 'bg-white border'); ?> mb-5">
            <h1 class="display-4 mb-4">🚀 Laravel UI Integrated Demo</h1>
            <p class="lead">Demonstrasi lengkap Partial Views, Blade Components, dan Theme Switching dalam satu aplikasi terpadu.</p>
            
            <div class="row mt-5">
                <div class="col-md-4 mb-4">
                    <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FeatureCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Partial Views','icon' => '📁','description' => 'Gunakan @include untuk reusable UI components dengan data sederhana.','badge' => 'Latihan 13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4 mb-4">
                    <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FeatureCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Blade Components','icon' => '🧩','description' => 'Komponen Blade dengan props dan slots untuk UI yang lebih kompleks.','badge' => 'Latihan 14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
                </div>
                <div class="col-md-4 mb-4">
                    <?php if (isset($component)) { $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07 = $attributes; } ?>
<?php $component = App\View\Components\FeatureCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feature-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FeatureCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Theme Switching','icon' => '🎨','description' => 'Toggle antara light dan dark mode dengan session persistence.','badge' => 'Latihan 15']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $attributes = $__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__attributesOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07)): ?>
<?php $component = $__componentOriginal6660e6d9c57bcffaf37d76b59d296f07; ?>
<?php unset($__componentOriginal6660e6d9c57bcffaf37d76b59d296f07); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card <?php echo e($theme === 'dark' ? 'bg-dark border-light' : ''); ?> mb-4">
                    <div class="card-header">
                        <h5>Fitur Utama</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item <?php echo e($theme === 'dark' ? 'bg-dark text-light' : ''); ?>">
                                - <?php echo e($feature); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card <?php echo e($theme === 'dark' ? 'bg-dark border-light' : ''); ?>">
                    <div class="card-header">
                        <h5>Teknologi yang Digunakan</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-primary">Laravel 12</span>
                            <span class="badge bg-success">Blade Templates</span>
                            <span class="badge bg-info">Bootstrap 5</span>
                            <span class="badge bg-warning">PHP 8.4</span>
                            <span class="badge bg-danger">Session Management</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/home.blade.php ENDPATH**/ ?>