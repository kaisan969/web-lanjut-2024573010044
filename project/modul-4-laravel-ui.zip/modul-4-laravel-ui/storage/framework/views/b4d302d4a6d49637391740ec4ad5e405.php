<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['theme' => 'light', 'icon' => null, 'title' => '', 'description' => '', 'badge' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['theme' => 'light', 'icon' => null, 'title' => '', 'description' => '', 'badge' => null]); ?>
<?php foreach (array_filter((['theme' => 'light', 'icon' => null, 'title' => '', 'description' => '', 'badge' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<footer class="mt-5 py-4 border-top <?php echo e($theme === 'dark' ? 'border-secondary' : ''); ?>">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>Laravel UI Integrated Demo</h5>
                <p class="mb-0">Demonstrasi Partial Views, Blade Components, dan Theme Switching</p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0">
                    <strong>Current Theme:</strong> 
                    <span class="badge <?php echo e($theme === 'dark' ? 'bg-primary' : 'bg-dark'); ?>">
                        <?php echo e(ucfirst($theme)); ?>

                    </span>
                </p>
                <p class="mb-0">&copy; 2024 Laravel UI Demo. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH E:\worshop lanjut s3\web-lanjut-2024573010044\project\modul-4-laravel-ui\resources\views/components/footer.blade.php ENDPATH**/ ?>